

ggplot(omitednavalues, aes(x=pretest, y=posttest)) + geom_point()

ggplot(omitednavalues, aes(x=pretest, y=posttest)) + geom_point()+ geom_smooth()

ggplot(omitednavalues, aes(x=pretest, y=posttest)) + geom_point()+ geom_smooth(method=lm)

ggplot(omitednavalues, aes(x=pretest, y=posttest, shape=gender)) + geom_point() + geom_smooth(method=lm)

ggplot(omitednavalues,aes(pretest, posttest ) ) + geom_smooth(method = "lm") +geom_point() + facet_grid(gender ~ .)