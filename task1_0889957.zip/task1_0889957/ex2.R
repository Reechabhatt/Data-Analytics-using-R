
ggplot(data=omitednavalues, ) + geom_histogram( aes(posttest, ..density..),bins=20 ,color='white') + geom_density( aes(posttest, ..density..) ) +geom_rug( aes(posttest) )

ggplot(omitednavalues ) + geom_histogram( aes(posttest)) +facet_grid(gender ~ .)+geom_rug( aes(posttest) )