mydata100 <- read.csv("C:/Users/SHAHIPARTH/Downloads/mydata100.csv", header=TRUE ,sep=",")
View(mydata100)
head(mydata100)
na.omit(mydata100)
omitednavalues=na.omit(mydata100)
ex:1(a)
qplot(workshop,data=omitednavalues)

ex:2(b)
qplot(workshop,data=omitednavalues) +coord_flip()

ex:3(c)
ggplot(omitednavalues, aes(workshop,fill=workshop)) +geom_bar()

ex:4(d)
ggplot(omitednavalues, aes(gender,fill=workshop)) +geom_bar(position = position_stack(reverse = TRUE))