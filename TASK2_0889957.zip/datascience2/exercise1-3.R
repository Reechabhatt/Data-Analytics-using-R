mydataset2_new
state.x77
class(state.x77)
r<-as.data.frame(state.x77)
nrow(subset(r, r$Income <4300))
row.names(r)[(which(max(r$Income)==r$Income))]

write.csv(state.x77,'state-data.csv')
mydataset2_new<-read.csv(file = "state-data.csv")
mydataset2_new

colnames(mydataset2_new)[1] <- "States"
mydataset2_new

mydataset2_new$abbrev<-state.abb[match(mydataset2_new$States,state.name)]
mydataset2_new

write.csv(state.x77,'state-Data.csv')
mystate<-read.csv(file = "state_Data.csv")
mystate

colnames(mystate)[1] <- "States"
mystate

mystate$abbrev<-state.abb[match(mystate$States,state.name)]
mystate


NE.name <- c("Connecticut","Pennsylvania","Massachusetts","New Hampshire","Rhode,Island","Vermont","New Jersey","New York",
             "Maine")
NE <- c(NE.name)


NC.name <- c("Ohio","Illinois","Michigan","Indiana","Wisconsin","Iowa","Kansas","Minnesota","Missouri","Nebraska",
             "North Dakota","South Dakota")
NC <- c(NC.name)

S.name <- c("Alabama","District of Columbia","Florida","Georgia","Maryland","North Carolina","South Carolina","Virginia",
            "West Virginia","Delaware","Kentucky","Mississippi", "Tennessee","Arkansas","Louisiana","Oklahoma","Texas")

S <- c(S.name)

W.name <- c("Arizona","Colorado","Idaho","Montana","Washington","Utah","Nevada","Wyoming","Alaska","California",
            "Hawaii","Oregon","New Mexico")
W <- c(W.name)

region <- list(Northeast=NE,NorthCenter=NC,South=S,West=W)


mystate$Regions <- sapply(mystate$States, 
                          function(x) names(region)[grep(x,region)])
mystate


trimws(mystate, which = c("both", "left", "right"))
mystate


write.csv(mystate_new,'state-data.csv')
mystate_new<-read.csv(file = "state-data.csv")
mystate_new
