install.packages("ggplot2")
library(ggplot2)
##################################### ex4 #######################################
mystate_new<-read.csv(file = "state_data.csv")
mystate_new
ggplot(mystate_new, aes(x=Illiteracy, y=LifeExp)) + geom_point()

ggplot(mydataset2, aes(x=Illiteracy, y=LifeExp))  +geom_text(aes(label=Abbrev))

ggplot(mydataset2, aes(Murder)) +
  geom_histogram() +  scale_x_continuous(breaks = 5)
ggplot(mydataset2, aes(x=Murder,y= state.region)) + geom_point()

########################### exc5##############################
ggplot(mydataset2, aes(x=Illiteracy, y=LifeExp)) + geom_point(size=2) + 
  theme_grey() + geom_smooth()


##################### Exercise 6 ##################
ggplot(mydataset2,aes(Population)) + geom_histogram() mydataset2
ggplot(mydataset2,aes(Population)) + geom_histogram() + xlab("Population (thousands)") + ylab("Number of States")

ggplot(mydataset2,aes(Population)) + geom_histogram() + facet_wrap(Region ~ .)


############## Exercise 7 #################

ggplot(mydataset2, aes(x=Illiteracy, y=LifeExp)) + geom_point(size=3,aes(colour = factor(Region))) + 
  theme_grey()

############ Exercise 8 ###################

ggplot(mydataset2, aes(x=Illiteracy, y=LifeExp)) + geom_text(label=mydataset2$Abbrev,aes(colour = factor(Region),size = Population)) +
  theme_grey() + facet_grid(. ~ IncomeGroup) + coord_cartesian(ylim=c(66.7, 75)) + scale_y_continuous(breaks=seq(68,74,2)) + geom_smooth(size=1.2)
