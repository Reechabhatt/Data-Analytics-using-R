
#creating dtm into training and testing
mynewdata_train <- mynewdata_corpus_dtm1[1:4460, ]
mynewdata_test  <- mynewdata_corpus_dtm1[4461:5574, ]

mynewdata_train
mynewdata_test
