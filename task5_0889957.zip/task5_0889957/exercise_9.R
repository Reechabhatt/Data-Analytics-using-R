
install.packages("wordcloud")
library("wordcloud")
#creating the world cloud
wordcloud(mynewdata_corpus, min.freq = 60, random.order = FALSE)
#wordcloud(mynewdata_corpus_dtm, min.freq = 60, random.order = FALSE)
#wordcloud(mynewdata_test, min.freq = 60, random.order = FALSE)

mynewdata_train_dtm1 <- mynewdata_corpus_dtm1[1:4460, ]
mynewdata_test_dtm1 <- mynewdata_corpus_dtm1[4461:5574, ]

frequency<- colSums(mynewdata_train_dtm1)
frequency2<- colSums(mynewdata_test_dtm1)

frequency<- sort(frequency, decreasing = TRUE)
head(frequency)
frequency2<- sort(frequency2, decreasing = TRUE)
head(frequency2)

words<- names(frequency)
words1<- names(frequency2)
wordcloud(words[1:100], frequency[1:100], colors = brewer.pal(6, "Dark2"))
wordcloud(words1[1:100], frequency2[1:100], colors = brewer.pal(6, "Dark2"))



