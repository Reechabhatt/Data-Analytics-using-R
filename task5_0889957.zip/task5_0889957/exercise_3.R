
#creating the corpus using "tm" library
library("tm")

mynewdata_corpus <- VCorpus(VectorSource(mynewdata$text))  
print(mynewdata_corpus)
