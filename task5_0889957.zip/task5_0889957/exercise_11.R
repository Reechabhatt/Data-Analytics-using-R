install.packages("e1071")

library("e1071")

spam_train_labels <- mynewdata[1:4460,]$type
spam_test_labels <-  mynewdata[4461:5574,]$type

spam_dtm_freq_train<- mynewdata_train[ , freq_words]
spam_dtm_freq_test <- mynewdata_test[ , freq_words]

convert_counts <- function(x) {
  x <- ifelse(x > 0, "Yes", "No")
}

spam_train <- apply(spam_dtm_freq_train, MARGIN = 2, convert_counts)
spam_test <- apply(spam_dtm_freq_test, MARGIN = 2, convert_counts)

spam_classifier <- naiveBayes(spam_train, spam_train_labels)
spam_test_pred <- predict(spam_classifier, spam_test)

table(spam_test_pred, spam_test_labels)

