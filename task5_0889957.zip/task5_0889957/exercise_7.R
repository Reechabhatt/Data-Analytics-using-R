#inspection of generated dtm
inspect(mynewdata_corpus_dtm)

