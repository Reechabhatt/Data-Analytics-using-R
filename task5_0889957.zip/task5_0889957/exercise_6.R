#creating dtm for cleaned corpus
mynewdata_corpus_dtm <- DocumentTermMatrix(mynewdata_corpus)
mynewdata_corpus_dtm1 <-as.matrix(mynewdata_corpus_dtm)
mynewdata_corpus_dtm
mynewdata_corpus_dtm1

