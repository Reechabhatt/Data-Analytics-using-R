#LOADING DATASET
mynewdata<-read.csv(file="C:/Users/SHAHIPARTH/Desktop/spam_ham.csv")
mynewdata
str(myData_new)

mynewdata$type <- factor(mynewdata$type)
mynewdata$text <- factor(mynewdata$text)
str(mynewdata)

