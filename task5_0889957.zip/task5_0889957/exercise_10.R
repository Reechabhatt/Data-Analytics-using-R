#printing the frequent word of training and testing dtm
freq_words<-findFreqTerms(mynewdata_train, 5)
freq_words
freq_words<-findFreqTerms(mynewdata_test, 5)
freq_words
