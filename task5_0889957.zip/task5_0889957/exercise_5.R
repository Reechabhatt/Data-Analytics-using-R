#cleaning the corpus
#changing characterS in to lower
corpus <- tm_map(corpus,content_transformer(tolower) )
#removing numbers
corpus <= tm_map(corpus,content_transformer(removeNumbers)  )
#removing punctuation
corpus <= tm_map(corpus, content_transformer(removePunctuation))
#stripping whitespace
corpus <= tm_map(corpus, content_transformer(stripWhitespace))

corpus


