#inspect the first three messages of the corpus
inspect(mynewdata_corpus[1:3])
