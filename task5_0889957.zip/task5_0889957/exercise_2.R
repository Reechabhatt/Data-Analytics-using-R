
#LOADING the DATASET
mynewdata<-read.csv(file="C:/Users/SHAHIPARTH/Desktop/spam_ham.csv")

#CHANGING THE TYPE
table(mynewdata$type)
