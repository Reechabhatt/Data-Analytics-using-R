# COMPARISION OF PACKAGES
library(rattle.data) 
str(weather)
# TREE PACKAGE
library(tree)
tree.decitree <- tree(RainTomorrow~Cloud3pm+Sunshine,method = "class",data=weather)
plot(tree.decitree)
text(tree.decitree ,all=TRUE,pretty = TRUE,splits = TRUE, cex = 1)
summary(tree.decitree)

# IT SHOWS THAT IT WONT RAIN IF THE VALUE OF THE cloudat3pm IS LESS THAN 6.5
# ALSO THE SUNSHINE IS CHECKED IF THE cloudat 3pm IS GREATER THAN 6.5 
# IT PREDICTS THAT IT WONT RAIN IF THE SUNSHINE IS GREATER THAN 9.5
# IT RAINS IF THE SUNSHINE IS LESS THAN 0.5 AND WHEN IT IS BETWEEN 8.75 AND 9.3

# CTREE PACKAGE
library(party)
ctree.decitree <- ctree(RainTomorrow~Cloud3pm+Sunshine,data=weather.data)
plot(ctree.decitree)

#DIFFERENCE
#The difference between the packages is the decision making capability OF cloudat3pm
