# CREATION OF DECISION TREE USING THE WEATHER DATA AND CTREE
library(party)
rainfallchances<- ctree(RainTomorrow ~ Sunshine + Pressure9am + Cloud9am, data =weather)
plot(rainfallchances)
