# DECISION TREE
library(tree)
decisiontree<- tree(play~outlook+windy+humidity,method = "class",data=dataset)
plot(decisiontree)
text(decisiontree ,all=TRUE,pretty = TRUE,splits = TRUE, cex = 1)
decisiontree
