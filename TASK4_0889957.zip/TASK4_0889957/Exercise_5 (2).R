library("forecast")

data<-read.csv(file="C:/Users/parag/Documents/Data_science/Task_4/Data_Analytics_Task4/AMZN.csv", head=TRUE, sep=",")
head(data)

data<- data[order(data$Date),]
head(data)
adj1<-data$Adj.Close
head(adj1)

amzn_ts1<- ts(adj1, frequency = 12 , start=c(2008,3))
amzn_ts1<-HoltWinters(amzn_ts1,gamma=F)
plot(amzn_ts1)
amzn_ts2<- forecast(amzn_ts1,h=19)
plot(amzn_ts2)
