pack<-read.csv(file="C:/Users/SHAHIPARTH/Downloads/AMZN.csv", head=TRUE, sep=",")
head(pack)

pack<- pack[order(pack$Date),]
adj1<-data$Adj.Close
head(adj1)

ts_adj<- ts(adj1,frequency = 12,start=c(2008, 3))
amzn_ts_log<- log(ts_adj)
plot.ts(amzn_ts_log)


#What you did you notice after applying the log additive model?

