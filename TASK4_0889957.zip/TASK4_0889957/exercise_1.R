
mynew_data =read.csv(file = "C:/Users/SHAHIPARTH/Downloads/AMZN.csv")
mynew_data
head(mynew_data,6) 


