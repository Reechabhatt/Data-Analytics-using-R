data<-read.csv(file="C:C:/Users/SHAHIPARTH/Downloads/AMZN.csv", head=TRUE, sep=",")
head(data)

data<- data[order(data$Date),]
head(data)

amzn_ts<- ts(data$Adj.Close,frequency = 12,start=c(2008, 3))
amzn_ts
plot.ts(amzn_ts)
