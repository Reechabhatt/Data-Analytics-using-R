pack<-read.csv(file="C:/Users/SHAHIPARTH/Downloads/AMZN.csv", head=TRUE, sep=",")
head(pack)

pack<- pack[order(pack$Date),]
adj<-pack$Adj.Close
head(adj)

amzn_ts<- ts(adj, frequency = 12 , start=c(2008,3))
head(amzn_ts)
amzn_ts<-decompose(amzn_ts)
plot(amzn_ts)

