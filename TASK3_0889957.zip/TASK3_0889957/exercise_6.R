

colnames(cars_m_h) <- c('model','mpg', 'hp')
cars_m_h
