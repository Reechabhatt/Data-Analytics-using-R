install.packages("tidyverse")

library(tidyverse)


mtcars %>% select(mpg, hp, vs:gear)
