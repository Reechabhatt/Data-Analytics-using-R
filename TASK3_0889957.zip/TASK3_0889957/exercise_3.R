install.packages("tidyverse")

library(tidyverse)


data(mtcars)


head(mtcars)



mtcars %>% select(-hp)
