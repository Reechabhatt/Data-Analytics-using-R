1
install.packages("tidyr")
install.packages("stringr")
install.packages("dplyr")

library(tidyr)
library(stringr)
library(dplyr)
tempfile<-"C:/Users/SHAHIPARTH/Desktop/assig3_0889957/tempfile.txt"
sales <- read.csv(tempfile, stringsAsFactors = FALSE, header = T, sep = "\n")
sales
sales %>% mutate(currency = str_extract(sales,"\\$|�") ) %>% 
mutate(raw_amount = str_replace_all(sales, ",|\\$|�", "") ) %>%
mutate(amount = as.numeric(raw_amount)) %>%
mutate(convertedAmountInUSD = ifelse(currency == '$', amount, ifelse(currency == '�', round(amount*1.29,2), NA)))

#########################################################################################################################
2.
install.packages("lubridate")

library(lubridate)
date_sep <- c("27-09-2017", "28-09-2017", "29-09-2017")
date <- as.Date(date_sep, format = "%d-%m-%Y")
wday(date, label = TRUE)

##########################################################################################################################################
3.
install.packages("tidyverse")

library(tidyverse)
data(mtcars)
head(mtcars)
mtcars %>% select(-hp)
##############################################################################################################################################
4.
mtcars %>% select(mpg, hp, vs:gear)

##############################################################################################################################################
5.
cars_m_h = mtcars %>% 
select(miles_per_gallon = mpg, horse_power = hp) %>% 
tibble::rownames_to_column(var = "model")
cars_m_h

##############################################################################################################################################
6.
colnames(cars_m_h) <- c('model','mpg', 'hp')
cars_m_h

###############################################################################################################################################
7.
cars_m_h_s = cars_m_h %>% slice(10:35)
cars_m_h_s

##############################################################################################################################################
8.
cars_m_h_s %>% distinct()

##############################################################################################################################################
9.
cars_m_h_s %>% filter(mpg > 20, hp> 100)

##############################################################################################################################################
10.
cars_m_h %>% filter( model == "Lotus Europa")

##############################################################################################################################################