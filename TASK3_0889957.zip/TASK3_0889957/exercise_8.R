install.packages("tidyverse")

library(tidyverse)


cars_m_h_s %>% distinct()


