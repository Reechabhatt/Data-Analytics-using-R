

cars_m_h %>% filter( model == "Lotus Europa")
