install.packages("tidyverse")

library(tidyverse)


cars_m_h = mtcars %>% 
  select(miles_per_gallon = mpg, horse_power = hp) %>% 
  tibble::rownames_to_column(var = "model")
cars_m_h
