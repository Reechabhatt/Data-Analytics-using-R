install.packages("tidyverse")

library(tidyverse)


cars_m_h_s = cars_m_h %>% slice(10:35)
cars_m_h_s