install.packages("tidyverse")

library(tidyverse)


cars_m_h_s %>% filter(mpg > 20, hp> 100)
